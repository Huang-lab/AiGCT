import sys

def testf(df):
    print("yeay1")
    display(df.style)