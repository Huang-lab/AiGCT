# AI Genomics CollecTive (AIGCT)

## Overview

AI Genomics CollecTive (AIGCT) is a platform for systematically 
evaluating ML/AI models of variant effects across the spectrum of 
genomics-based precision medicine.

## Development Documentation Including Installation and Usage Instructions

Use these instructions for installation of the development version for internal testing
rather than the installation instructions in the readthedocs documentation below.
For usage refer to the readthedocs documentation.




## Documentation Including Installation and Usage Instructions

**[readthedocs](https://aigct-dev.readthedocs.io/en/latest/index.html#)**
